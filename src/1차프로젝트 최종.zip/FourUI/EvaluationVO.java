package FourUI;

public class EvaluationVO extends UserVO{

	public EvaluationVO(String id, String pw, String name, int pv_num, String ph_num, String addr) {
		super(id, pw, name, pv_num, ph_num, addr);
		// TODO Auto-generated constructor stub
	}

}
